package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(name="Servo", group="Linear OpMode")
public class Servo_Test_Controller extends LinearOpMode {

    private ElapsedTime runtime = new ElapsedTime();
    Servo servo1;
    double servoPosition = 0.0;

    @Override
    public void runOpMode() throws InterruptedException {
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        servo1 = hardwareMap.servo.get("servo1");
        servo1.setPosition(servoPosition);

        waitForStart();
        runtime.reset();

        servoPosition = 0.5;
        servo1.setPosition(servoPosition);

        sleep(3000);

        servoPosition = 1.0;
        servo1.setPosition(servoPosition);



    }
}
