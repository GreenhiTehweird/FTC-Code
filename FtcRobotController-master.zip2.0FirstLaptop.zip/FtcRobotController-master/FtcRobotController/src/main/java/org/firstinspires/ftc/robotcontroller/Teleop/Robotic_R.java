package org.firstinspires.ftc.robotcontroller.Teleop;

import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.hardwareMap;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(name="motor1")
public class Robotic_R extends OpMode  {

    ElapsedTime runtime = new ElapsedTime();

    DcMotor motor;
    DcMotor motor1;

    public void init(){
        motor = hardwareMap.dcMotor.get("motor1");
        motor1 = hardwareMap.dcMotor.get("motor2");
    }

    public void loop(){
        motor.setPower(0.5);
        motor1.setPower(-0.5);
    }
}
