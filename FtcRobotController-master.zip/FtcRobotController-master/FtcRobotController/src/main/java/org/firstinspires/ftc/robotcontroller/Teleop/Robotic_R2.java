package org.firstinspires.ftc.robotcontroller.Teleop;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;

@TeleOp(name="ControllerPad", group="Linear Opmode")
public class Robotic_R2 extends LinearOpMode {

    private ElapsedTime runtime = new ElapsedTime();

    DcMotor motor;
    DcMotor motor1;

    @Override
    public void runOpMode() throws InterruptedException {
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        motor = hardwareMap.dcMotor.get("motor1");
        motor1 = hardwareMap.dcMotor.get("motor2");

        double motorwheelPower;
        double motorwheelPower1;
        double motorwheelPower2;

        motor.setDirection(DcMotorSimple.Direction.REVERSE);
        motor1.setDirection(DcMotorSimple.Direction.FORWARD);

        waitForStart();
        runtime.reset();

        while (opModeIsActive()) {
            telemetry.addData("Status", "Run Time: " + runtime.toString());
            telemetry.update();

            motorwheelPower = gamepad1.left_stick_y/2;
            motorwheelPower1 = -gamepad1.left_stick_x/1.25;



            motor.setPower(motorwheelPower);
            motor1.setPower(motorwheelPower);
            motor.setPower(motorwheelPower1);


        }

        }

    }
