package org.firstinspires.ftc.robotcontroller.Teleop;

import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.hardwareMap;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(name="motor1")
public class Robotic_R extends OpMode  {

    ElapsedTime runtime = new ElapsedTime();

    DcMotor backLeftMot;
    DcMotor backRightMot;

    public void init(){
        backLeftMot = hardwareMap.dcMotor.get("motor1");
        backRightMot = hardwareMap.dcMotor.get("motor2");
    }

    public void loop(){
        backLeftMot.setPower(0.5);
        backRightMot.setPower(-0.5);
    }
}
