//package org.firstinspires.ftc.teamcode;
//
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//import com.qualcomm.robotcore.hardware.DcMotor;
//import com.qualcomm.robotcore.hardware.DcMotorSimple;
//import com.qualcomm.robotcore.hardware.Servo;
//import com.qualcomm.robotcore.util.ElapsedTime;
//
//@TeleOp(name="ControllerPad", group="Linear Opmode")
//public class Controller_Code_Mecha extends LinearOpMode {
//
//    private ElapsedTime runtime = new ElapsedTime();
//
//    DcMotor backLeftMot;
//    DcMotor backRightMot;
//    DcMotor frontLeftMot;
//    DcMotor frontRightMot;
//
//    Servo servo;
//    Servo servo1;
//    double servoPosition = 0.0;
//
//    @Override
//    public void runOpMode() throws InterruptedException {
//        telemetry.addData("Status", "Initialized");
//        telemetry.update();
//
//        backLeftMot = hardwareMap.dcMotor.get("backLeftMot");
//        backRightMot = hardwareMap.dcMotor.get("backRightMot");
//        frontLeftMot = hardwareMap.dcMotor.get("frontLeftMot");
//        frontRightMot = hardwareMap.dcMotor.get("frontRightMot");
//
//        servo = hardwareMap.servo.get("servo1");
//        servo1 = hardwareMap.servo.get("servo2");
//
//        servo.setDirection(Servo.Direction.FORWARD);
//        servo1.setDirection(Servo.Direction.REVERSE);
//
//        backLeftMot.setDirection(DcMotorSimple.Direction.REVERSE);
//        frontLeftMot.setDirection(DcMotorSimple.Direction.REVERSE);
//
//        waitForStart();
//        runtime.reset();
//
//        while (opModeIsActive()) {
//            telemetry.addData("Status", "Run Time: " + runtime.toString());
//            telemetry.update();
//
//            backLeftMot.setPower(gamepad1.left_stick_y + gamepad1.right_stick_x - gamepad1.left_stick_x);
//            backRightMot.setPower(gamepad1.left_stick_y - gamepad1.right_stick_x + gamepad1.left_stick_x);
//            frontLeftMot.setPower(gamepad1.left_stick_y + gamepad1.right_stick_x + gamepad1.left_stick_x);
//            frontRightMot.setPower(gamepad1.left_stick_y - gamepad1.right_stick_x - gamepad1.left_stick_x);
//
//            if (gamepad1.x) {
//                servo.setPosition(0);
//                servo1.setPosition(0);
//
//            } else {
//                servo.setPosition(1);
//                servo1.setPosition(1);
//            }
//        }
//
//    }
//
//}