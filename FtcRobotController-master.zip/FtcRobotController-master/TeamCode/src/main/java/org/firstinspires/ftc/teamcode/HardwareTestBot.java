package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.DcMotor;

public class HardwareTestBot {
    public DcMotor LeftMot;
    public DcMotor RightMot;
    public ColorSensor ColorSensor;

    HardwareMap hwMap;
    private ElapsedTime period = new ElapsedTime();

    public HardwareTestBot(){

    }
    public void init(HardwareMap ahwMap){
        hwMap = ahwMap;

        LeftMot = hwMap.get(DcMotor.class, "LeftMot");
        RightMot = hwMap.get(DcMotor.class, "RightMot");

        LeftMot.setPower(0);
        RightMot.setPower(0);

        LeftMot.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        RightMot.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        ColorSensor = hwMap.get(ColorSensor.class, "ColorSensor");




    }

}
