//package org.firstinspires.ftc.teamcode;
//
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//import com.qualcomm.robotcore.hardware.DcMotor;
//import com.qualcomm.robotcore.hardware.DcMotorSimple;
//import com.qualcomm.robotcore.hardware.Servo;
//import com.qualcomm.robotcore.util.ElapsedTime;
//
//
//    @TeleOp(name="ControllerPad", group="Linear Opmode")
//    public class Controller_Code extends LinearOpMode {
//
//        private ElapsedTime runtime = new ElapsedTime();
//
//        DcMotor LeftMot;
//        DcMotor RightMot;
//
//        Servo servo;
//        Servo servo1;
//        double servoPosition = 0.0;
//
//        @Override
//        public void runOpMode() throws InterruptedException {
//            telemetry.addData("Status", "Initialized");
//            telemetry.update();
//
//            LeftMot = hardwareMap.dcMotor.get("LeftMot");
//            RightMot = hardwareMap.dcMotor.get("RightMot");
//
//            servo = hardwareMap.servo.get("servo1");
//            servo1 = hardwareMap.servo.get("servo2");
//
//            double motorwheelPower;
//            double motorwheelPower1;
//
//
//            LeftMot.setDirection(DcMotorSimple.Direction.REVERSE);
//            RightMot.setDirection(DcMotorSimple.Direction.FORWARD);
//
//            servo.setDirection(Servo.Direction.FORWARD);
//            servo1.setDirection(Servo.Direction.REVERSE);
//
//            waitForStart();
//            runtime.reset();
//
//            while (opModeIsActive()) {
//                telemetry.addData("Status", "Run Time: " + runtime.toString());
//                telemetry.update();
//
//                motorwheelPower = gamepad1.left_stick_y/2;
//                motorwheelPower1 = -gamepad1.left_stick_x/2;
//
//                LeftMot.setPower(motorwheelPower);
//                RightMot.setPower(motorwheelPower);
//                LeftMot.setPower(motorwheelPower1);
//
//                if (gamepad1.x) {
//                    servo.setPosition(0);
//                    servo1.setPosition(0);
//
//                } else {
//                    servo.setPosition(0.25);
//                    servo1.setPosition(0.25);
//                }
//            }
//
//        }
//
//    }
