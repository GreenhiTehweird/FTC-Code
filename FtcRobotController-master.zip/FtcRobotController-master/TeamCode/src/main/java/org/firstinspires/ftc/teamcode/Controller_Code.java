package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;


    @TeleOp(name="ControllerPad", group="Linear Opmode")
    public class Controller_Code extends LinearOpMode {

        private ElapsedTime runtime = new ElapsedTime();

        DcMotor motor;
        DcMotor motor1;

        Servo servo;
        Servo servo1;
        double servoPosition = 0.0;

        @Override
        public void runOpMode() throws InterruptedException {
            telemetry.addData("Status", "Initialized");
            telemetry.update();

            motor = hardwareMap.dcMotor.get("motor1");
            motor1 = hardwareMap.dcMotor.get("motor2");

            servo = hardwareMap.servo.get("servo1");
            servo1 = hardwareMap.servo.get("servo2");

            double motorwheelPower;
            double motorwheelPower1;


            motor.setDirection(DcMotorSimple.Direction.REVERSE);
            motor1.setDirection(DcMotorSimple.Direction.FORWARD);

            waitForStart();
            runtime.reset();

            while (opModeIsActive()) {
                telemetry.addData("Status", "Run Time: " + runtime.toString());
                telemetry.update();

                motorwheelPower = gamepad1.left_stick_y/2;
                motorwheelPower1 = -gamepad1.left_stick_x/1.25;

                motor.setPower(motorwheelPower);
                motor1.setPower(motorwheelPower);
                motor.setPower(motorwheelPower1);

                if (gamepad1.x) {
                    servo.setPosition(0);
                    servo1.setPosition(0);

                } else {
                    servo.setPosition(0.25);
                    servo1.setPosition(0.25);
                }
            }

        }

    }
