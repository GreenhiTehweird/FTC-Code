package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.DcMotor;


public class Color_Sensor {
    public DcMotor DcMotor = null;
    @Autonomous(name="LeftMot")

    public class Robotic_R extends OpMode {

        HardwareMap hwMap = null;
        ElapsedTime runtime = new ElapsedTime();

        ColorSensor ColorSensor = null ;

        public void init(){
            ColorSensor = hardwareMap.colorSensor.get("Color");
        }

        public void loop(){
            ColorSensor.red();
            ColorSensor.green();
            ColorSensor.blue();
            ColorSensor.alpha();
            ColorSensor.argb();

            ColorSensor.enableLed(true);

            while (ColorSensor.alpha() < 20) {
                //drive forward
            }
            //raise claw
            //open claw

        }
    }
}

