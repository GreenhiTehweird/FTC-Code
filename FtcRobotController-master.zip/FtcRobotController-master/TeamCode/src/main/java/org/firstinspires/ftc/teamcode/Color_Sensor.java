package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.hardware.modernrobotics.ModernRoboticsI2cColorSensor;

public class Color_Sensor {

    @Autonomous(name="motor1")
    public class Robotic_R extends OpMode {

        ElapsedTime runtime = new ElapsedTime();

        DcMotor motor;
        DcMotor motor1;
        ModernRoboticsI2cColorSensor ColorSensor;

        public void init(){
            motor = hardwareMap.dcMotor.get("motor1");
            motor1 = hardwareMap.dcMotor.get("motor2");
        }

        public void loop(){
            motor.setPower(0.5);
            motor1.setPower(-0.5);

            ColorSensor = hardwareMap.get(ModernRoboticsI2cColorSensor.class, "ColorSensor1");


            telemetry.addData("Status", "Ready to run");
            telemetry.update();



        }
    }
}
